TRDP SPY
----------------------------------
Requirements:
Wireshark version 2.6, 3.0, 3.2, 3.4, 3.6 or 4.0

Features:
1. User data interpretation support
2. Multiple user data files

As of 3.6, I do not rebuild old binaries. They should build from source with minor adjustments.

Installation Instruction:
Copy trdp_spy.so (Linux)/ trdp_spy.dll (Win) into plugin directory
Set in Edit/Preferences/TRDP your specific trdp_config.xml.
This is needed to interpret the transmitted user data.

Please also see top-level README.
