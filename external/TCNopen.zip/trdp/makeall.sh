make LINUX_armhf_config
make clean DEBUG=TRUE libtrdp libtrdpap
make clean libtrdp libtrdpap

make ELINOS_x86_64_config
make clean DEBUG=TRUE libtrdp libtrdpap
make clean libtrdp libtrdpap

make LINUX_PPC_config
make clean DEBUG=TRUE libtrdp libtrdpap
make clean libtrdp libtrdpap

make LINUX_X86_config
make clean DEBUG=TRUE libtrdp libtrdpap
make clean libtrdp libtrdpap

make LINUX_X86_64_config
make clean DEBUG=TRUE libtrdp libtrdpap
make clean libtrdp libtrdpap

