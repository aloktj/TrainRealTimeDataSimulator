# TCNopen fork

## Bug fixes for TRDP spy

Currently I only rebuild the plugin for [Wireshark 4.0 Linux](trdp/spy/plugins/4.0/epan). I do not have the infrastructure to build other versions.

2023-August: The patch that brought little-endian interpretation was not complete and would do the wrong thing at times. Proper plugin-config-option added.

2023-April: Wireshark would crash if xml-file went missing.

## Repo is put to rest

As I wrote [before](#in-2021-and-2022):
> "The upstream project still receives active development but focuses on many goals. When I pull their additions, I notice that warning-free Linux compilation is not their primary focus, which also makes keeping up tiring."

So I will pause doing it. I may still add updates to [TRDP-SPY](trdp/spy/) Wireshark plugin here in the master-branch, but don't count on it.

I will also only react to issues concerning the Wireshark plugin and code that I added beyond upstream.

## About 
This is a "private" fork of TCNopen (Components for IEC61375 standardised communication)

**Now awesome**: 
Debian packaging is there! See below for news on 2020.

I rewrote the Wireshark Plugin [TRDP-SPY](trdp/spy/) for current Wireshark. Compiled binaries are available for versions [2.6](trdp/spy/plugins/2.6/epan), [3.0](trdp/spy/plugins/3.0/epan), [3.2](trdp/spy/plugins/3.2/epan), [3.4](trdp/spy/plugins/3.4/epan), [3.6](trdp/spy/plugins/3.6/epan) and [4.0](trdp/spy/plugins/4.0/epan). It now really works for Datasets, Arrays, Strings and filtering on names. Try it out! Create an issue if it doesn't work for you. Please be verbose if I misinterpreted the standard somewhere. From the latest revision (only available for Wireshark 3.6) you can load a folder full of XML-configs.

## Goal of fork
 - The [master](https://github.com/T12z/TCNopen/tree/master) for me to play around.
 - The [upstream](https://github.com/T12z/TCNopen/tree/upstream) if all you need is a mirror.
 - Nothing else, no product, no specific enhancements.

## Building with CMake (next steps)
The repository now ships a full CMake build that mirrors the legacy `make` targets. Presets are provided so you can get started with
`cmake --list-presets` and pick the configuration that best matches your workflow (release, debug, high-performance, TSN-focused,
or "libraries only"). To try it out or consume this tree as a submodule:

1. **Configure** – pick one of the existing legacy configs (or disable the import by passing `TRDP_LEGACY_CONFIG=NONE`) and run
   either the preset or a fully manual invocation. For example, to mirror the Linux default you can now do:
   ```sh
   cmake --preset linux-posix-release
   ```
   or keep crafting the cache variables explicitly:
   ```sh
   cmake -S . -B build -DTRDP_LEGACY_CONFIG=LINUX_X86_64_config \
         -DTRDP_BUILD_EXAMPLES=ON -DTRDP_BUILD_TESTS=ON
   ```
   All feature switches from the Makefiles (TSN, MD, SOA, etc.) are exposed as cache options with the prefix `TRDP_` and default to the values that were parsed from the selected legacy config.
2. **Build** – request the libraries or helper tools you need, either through presets …
   ```sh
   cmake --build --preset build-linux-posix-release --target trdp trdpap example
   ```
   …or by invoking the generator directly:
   ```sh
   cmake --build build --target trdp trdpap example echoCallback mdManager
   ```
   The layout under `build/bld/output/<arch>-{rel,dbg}` matches the existing `make` output, so manual packaging/scripts continue to work.
3. **Install / reuse** – to install locally run `cmake --install build`. If you are embedding this repository into a larger CMake project, add it as a submodule and call `add_subdirectory(trdp)` from your super-project; link to the exported targets `TRDP::trdp` or `TRDP::trdpap` just like any other package.

If you are unsure which presets, feature toggles, or executable targets to combine, run `cmake --build <build-dir> --target help` (or `--target trdp-help`). The target prints the curated summary that used to live in the legacy `make help` output so you can see how to select configs, which cache variables guard the TSN/high-performance/test suites, and which sample binaries depend on libuuid. (The Ninja generator reserves the built-in `help` target, so on that generator you must request `trdp-help` directly.)

To exercise *all* Linux configurations without typing each preset manually, run `scripts/build_linux_matrix.sh`. The helper loops over the release, debug, minimal, high-performance, and TSN presets, driving both `cmake --preset <name>` and the matching build preset so every archive/executable lands in `build/<preset>/bld/output/…`. Cross builds need external toolchains, so after exporting the environment variables noted below (`TRDP_VXWORKS_TOOLCHAIN_PREFIX` for VxWorks, `TRDP_INTEGRITY_COMPILER` for INTEGRITY) you can call `scripts/build_cross_matrix.sh` to batch-configure and build those presets as well.

### Cross-platform presets & ESP-IDF support
* **VxWorks / INTEGRITY** – dedicated configure presets (`vxworks-ppc`, `integrity-posix`) wire the build up to the new toolchain files under `cmake/toolchains/`. Point `TRDP_VXWORKS_TOOLCHAIN_PREFIX` at your Wind River cross tool prefix (e.g., `/opt/WindRiver/.../powerpc-wrs-vxworks-`) or `TRDP_INTEGRITY_COMPILER` at your Green Hills `cc` binary before invoking `cmake --preset <name>`. The presets automatically pick the matching legacy configuration and pass `TRDP_TARGET_OS` so the compile definitions mirror the GNU Make flow.
* **ESP-IDF** – the `src/vos/esp/CMakeLists.txt` file mirrors the legacy `component.mk`. Drop the `trdp/src/vos/esp` directory into your `components/` tree and IDF will register all common/VOS sources with the same warning/endianness flags as before.

The goal for the next iteration is to exercise the presets with the most relevant configs (Linux, VxWorks, INTEGRITY) and iron out portability bugs before replacing the legacy Makefiles.

## In 2017
 - I updated the TRDP-Spy plugin to wireshark 2.5. Later on, Upstream have updated the plugin to a 2.x version as well, so I split this off to an [archive branch](https://github.com/T12z/TCNopen/tree/wireshark2.5). 
 - I also started into looking how to pair that up with SCADE but got off-tracked into "paid work". Currently it is *nothing* useful. Don't bother looking. If there is more interest in this topic send me some kind of thumbs-up, so I feel like I should get back onto it.
 
## In 2018
 - So I synced an update, yet haven't really looked into it. But I did trash the branch history, sorry for that!
 - In future, I will try to separate [upstream](https://github.com/T12z/TCNopen/tree/upstream) and my work, so the git-svn shuffling might work smoother.

## In 2019
 - I finally gave up on all my git misery and rebooted the repo. Syncing with upstream became a huge pain and everytime git-bugs piled up. I am **absolutely deeply sorry** for everyone, who had a clone and now has to restart.
 - I built a TRDP application that uses a wrapper around the XML stuff, partially based on the original example.
 - This wrapper is again lightly cling-wrapped to be usable from C++/Qt. Planning to publish it a.s.a.p. (As of writing, it still has too many dependencies on other stuff.)
 - Finally, I also use [Ansys SCADE](https://www.ansys.com/de-de/products/embedded-software/ansys-scade-suite), a lot, and have it working with TRDP nicely. However, if you are not using SCADE, you're in for pain. Currently, I am trying to trim a middle way, please hold on for a few weeks or drop me line.

## In 2020
 Some more Linux features:
 - Debian packaging and shared libraries added for Linux.
 - You now can build the Wireshark plugin on Linux w/o the Wireshark source - just from the spy tree via make or from the root with debuild.
 - How build the Debian packages? Install the build-dependencies (Build-Depends: debhelper (>= 12.8), doxygen, libwireshark-dev (>= 2.6), libglib2.0-dev, graphviz), go into tcnopen-trdp/trdp and run "make bindeb-pkg" to build the lib and the wireshark plugin packages. Install them with "sudo dpkg -i ../*.deb". Wireshark will find its plugin automatically and your Linux compiler should find the headers also. Only need to add -ltrdp -ltau or -ltrdp-hp -ltau-hp to the linker of your applications.
 With this, I will not pre-build the Wireshark plugins anymore. Please checkout the upstream branch for older pre-build plugin binaries 2.6, 3.0 and 3.2.
 - Actually, I added the plugins for 3.4 for convenience for a last time.

## In 2021 and 2022
 I moved jobs and now work for Stadler Rail. I am not using TRDP on any recurring basis anymore in my position (rather MQTT, VDV301 ...). So this repo will wind down even further in updates.
 Some upgrades and bugfixes in the SPY were pushed. Building for Windows is still quite annoying and eats precious time.
 The upstream project still receives active development but focuses on many goals. When I pull their additions, I notice that warning-free Linux compilation is not their primary focus, which also makes keeping up tiring. You'll also notice some [differences](https://github.com/T12z/TCNopen/compare/upstream...master) between [upstream](https://github.com/T12z/TCNopen/tree/upstream) and [master](https://github.com/T12z/TCNopen/tree/master)

## Missing
 - Regular Updates. This is NOT in sync nor latest update from original sourceforge SVN
 - Support. I am no TRDP expert, neither have I project funds to work on TRDP

More information from SourceForge site: https://sourceforge.net/projects/tcnopen/

# Original Description

TCNOpen is an open source initiative which the partner railway industries created with the aim to build in collaboration some key parts of new or upcoming railway standards, commonly known under the name TCN.
TCN (Train Communication Network) is a series of international standards (IEC61375) developed by Working Group 43 of the IEC (International Electrotechnical Commission), specifying a communication system for the data communication within and between vehicles of a train. It is currently in use on many thousands of trains in the world in order to allow electronic devices to exchange information while operating aboard the same train.
TCNOpen follows the Open Source scheme, as the software is jointly developed by participating companies, according to their role, so as to achieve cheaper, quicker and better quality results.

## Licenses

TRDP: MPLv2.0 http://www.mozilla.org/MPL/2.0/ 

TRDPSpy: GPL http://www.gnu.org/licenses/gpl.html 

TCNOpen Web Site http://www.tcnopen.eu/
